"use client";

import { useEffect, useState } from "react";
import { Pencil, ImagePlus, CalendarDays, UserRound, MessageSquare, Share2, X, Users, Copy, ShieldCheck } from "lucide-react";

type Gender = "girl" | "boy";
type CardData = { gender: Gender; name: string; date: string; message: string; images: string[] };
const KEY = "birthday-card-v3";
const OLD_KEY = "birthday-card-v2";
const IMAGE_COUNT = 12;

const emptyImages = () => Array.from({ length: IMAGE_COUNT }, () => "");

function normalize(data: any): CardData {
  const images = Array.isArray(data?.images) ? data.images.slice(0, IMAGE_COUNT) : [];
  while (images.length < IMAGE_COUNT) images.push("");
  if (data?.image && !images[0]) images[0] = data.image;
  return {
    gender: data?.gender === "boy" ? "boy" : "girl",
    name: data?.name || "",
    date: data?.date || "",
    message: data?.message || "",
    images,
  };
}

function bytesToBase64(bytes: Uint8Array) {
  let binary = "";
  const chunk = 0x8000;
  for (let i = 0; i < bytes.length; i += chunk) binary += String.fromCharCode(...bytes.subarray(i, i + chunk));
  return btoa(binary).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
}

function base64ToBytes(value: string) {
  const base = value.replace(/-/g, "+").replace(/_/g, "/") + "===".slice((value.length + 3) % 4);
  const binary = atob(base);
  return Uint8Array.from(binary, (c) => c.charCodeAt(0));
}

async function gzipEncode(data: CardData) {
  const raw = new TextEncoder().encode(JSON.stringify(data));
  if ("CompressionStream" in window) {
    const stream = new CompressionStream("gzip");
    const writer = stream.writable.getWriter();
    await writer.write(raw);
    await writer.close();
    const compressed = new Uint8Array(await new Response(stream.readable).arrayBuffer());
    return `g.${bytesToBase64(compressed)}`;
  }
  return `u.${bytesToBase64(raw)}`;
}

async function gzipDecode(value: string): Promise<CardData | null> {
  try {
    const [kind, payload] = value.split(".", 2);
    const bytes = base64ToBytes(payload || value);
    let raw = bytes;
    if (kind === "g" && "DecompressionStream" in window) {
      const stream = new DecompressionStream("gzip");
      const writer = stream.writable.getWriter();
      await writer.write(bytes);
      await writer.close();
      raw = new Uint8Array(await new Response(stream.readable).arrayBuffer());
    }
    return normalize(JSON.parse(new TextDecoder().decode(raw)));
  } catch {
    return null;
  }
}

async function legacyDecode(value: string): Promise<CardData | null> {
  try {
    const bytes = base64ToBytes(value);
    return normalize(JSON.parse(new TextDecoder().decode(bytes)));
  } catch {
    return null;
  }
}

async function compressImage(file: File) {
  const url = URL.createObjectURL(file);
  const img = new Image();
  try {
    await new Promise<void>((resolve, reject) => {
      img.onload = () => resolve();
      img.onerror = () => reject(new Error("Image could not be read"));
      img.src = url;
    });
    const max = 420;
    const scale = Math.min(1, max / Math.max(img.naturalWidth, img.naturalHeight));
    const canvas = document.createElement("canvas");
    canvas.width = Math.max(1, Math.round(img.naturalWidth * scale));
    canvas.height = Math.max(1, Math.round(img.naturalHeight * scale));
    const ctx = canvas.getContext("2d");
    if (!ctx) throw new Error("Canvas unavailable");
    ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
    return canvas.toDataURL("image/jpeg", 0.5);
  } finally {
    URL.revokeObjectURL(url);
  }
}

async function readCardFromUrl() {
  if (typeof window === "undefined") return null;
  const params = new URLSearchParams(window.location.search);
  const compact = params.get("c");
  if (compact) return gzipDecode(compact);
  const hash = new URLSearchParams(window.location.hash.slice(1));
  const encoded = hash.get("card");
  return encoded ? legacyDecode(encoded) : null;
}

export default function PersonalizeBirthday() {
  const blank: CardData = { gender: "girl", name: "", date: "", message: "", images: emptyImages() };
  const [data, setData] = useState<CardData>(blank);
  const [savedData, setSavedData] = useState<CardData>(blank);
  const [open, setOpen] = useState(false);
  const [hasCard, setHasCard] = useState(false);
  const [saving, setSaving] = useState(false);
  const [copied, setCopied] = useState(false);
  const [paymentOpen, setPaymentOpen] = useState(false);
  const [paymentUtr, setPaymentUtr] = useState("");
  const [pendingSave, setPendingSave] = useState(false);
  const [paymentMode, setPaymentMode] = useState<"secure" | "manual">("manual");

  useEffect(() => {
    let active = true;
    (async () => {
      const fromUrl = await readCardFromUrl();
      if (!active) return;
      if (fromUrl) {
        setData(fromUrl); setSavedData(fromUrl); setHasCard(true);
        localStorage.setItem(KEY, JSON.stringify(fromUrl));
        return;
      }
      try {
        const raw = localStorage.getItem(KEY) || localStorage.getItem(OLD_KEY);
        if (!raw) return;
        const saved = normalize(JSON.parse(raw));
        if (saved.name || saved.date || saved.images.some(Boolean)) {
          setData(saved); setSavedData(saved); setHasCard(true);
        }
      } catch {}
    })();
    return () => { active = false; };
  }, []);

  useEffect(() => {
    const iframe = document.querySelector<HTMLIFrameElement>('iframe[title="Birthday Reveal"]');
    if (!iframe || !hasCard) return;
    const url = new URL("/birthday.html", window.location.origin);
    if (savedData.date) url.searchParams.set("date", savedData.date);
    if (savedData.name) url.searchParams.set("name", savedData.name);
    if (savedData.message) url.searchParams.set("message", savedData.message);
    url.searchParams.set("gender", savedData.gender);
    iframe.src = url.toString();
    window.dispatchEvent(new Event("birthday-personalization-changed"));
  }, [hasCard, savedData.date, savedData.name, savedData.message, savedData.gender]);

  async function saveAndShare() {
    if (!data.name.trim() || !data.date) {
      alert("Please fill the required details (name and birthday date) first. Then payment will appear.");
      return;
    }
    setPendingSave(true);
    setPaymentOpen(true);
  }

  async function continueAfterPayment(verified = false) {
    if (!verified && !paymentUtr.trim()) {
      alert("Please enter the UTR / transaction ID after paying ₹49.");
      return;
    }
    setSaving(true);
    const clean = normalize(data);
    localStorage.setItem(KEY, JSON.stringify(clean));
    setSavedData(clean);
    const encoded = await gzipEncode(clean);
    const url = new URL(window.location.href);
    url.hash = "";
    url.searchParams.set("c", encoded);
    const fullUrl = url.toString();

    // Keep every existing personalization/image in the destination URL, but
    // copy a tiny redirect link for sharing. If the shortener is unavailable,
    // the complete link is still copied as a safe fallback.
    // The personalized URL is created locally first, so link creation never
    // depends on a third-party shortener. A short link is only an optional
    // enhancement and is given a hard timeout.
    let shareUrl = fullUrl;
    try {
      const controller = new AbortController();
      const timer = window.setTimeout(() => controller.abort(), 3000);
      try {
        const response = await fetch("/api/shorten", {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ url: fullUrl }),
          signal: controller.signal,
        });
        if (response.ok) {
          const result = await response.json();
          if (typeof result?.shortUrl === "string" && result.shortUrl) shareUrl = result.shortUrl;
        }
      } finally {
        window.clearTimeout(timer);
      }
    } catch {}

    history.replaceState(null, "", fullUrl);
    setData(clean); setHasCard(true); setOpen(false);
    window.dispatchEvent(new Event("birthday-personalization-changed"));
    try {
      await navigator.clipboard.writeText(shareUrl);
      setCopied(true); setTimeout(() => setCopied(false), 2200);
    } catch {}
    setSaving(false);
    setPaymentOpen(false);
    setPendingSave(false);
    setPaymentUtr("");
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  async function startSecurePayment() {
    setPaymentMode("secure");
    setSaving(true);
    try {
      const create = await fetch("/api/payment/create-order", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ amount: 4900 }) });
      const order = await create.json();
      if (!create.ok || !order?.id || !order?.keyId) throw new Error(order?.error || "Payment setup failed");

      await new Promise<void>((resolve, reject) => {
        if ((window as any).Razorpay) return resolve();
        const script = document.createElement("script");
        script.src = "https://checkout.razorpay.com/v1/checkout.js";
        script.onload = () => resolve();
        script.onerror = () => reject(new Error("Payment checkout could not load"));
        document.body.appendChild(script);
      });

      const Razorpay = (window as any).Razorpay;
      const checkout = new Razorpay({
        key: order.keyId, amount: order.amount, currency: "INR", name: "Birthday Card", description: "Birthday card link", order_id: order.id,
        handler: async (response: any) => {
          try {
            const verify = await fetch("/api/payment/verify", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(response) });
            const result = await verify.json();
            if (!verify.ok || !result?.verified) throw new Error(result?.error || "Payment verification failed");
            setPaymentUtr(response.razorpay_payment_id || "");
            await continueAfterPayment(true);
          } catch (error) {
            setSaving(false);
            alert(error instanceof Error ? error.message : "Payment verification failed");
          }
        },
        modal: { ondismiss: () => setSaving(false) },
        theme: { color: "#ec4899" },
      });
      checkout.on("payment.failed", () => { setSaving(false); alert("Payment failed. Please try again."); });
      checkout.open();
    } catch (error) {
      setSaving(false);
      setPaymentMode("manual");
      alert(error instanceof Error ? error.message : "Secure payment is not configured yet.");
    }
  }

  return (
    <>
      <section className="relative z-[30] flex min-h-[70vh] w-full snap-start items-center justify-center bg-black px-4 py-16 text-white">
        <div className="w-full max-w-3xl rounded-3xl border border-white/15 bg-white/[0.06] p-7 text-center shadow-2xl backdrop-blur-xl md:p-12">
          <div className="mx-auto mb-5 flex h-14 w-14 items-center justify-center rounded-full bg-fuchsia-500/20"><Share2 /></div>
          <h2 className="text-3xl font-bold md:text-5xl">Make It Yours Again</h2>
          <p className="mx-auto mt-3 max-w-xl text-sm text-white/65 md:text-base">Choose Girl or Boy, personalize the card, then share the generated link. The selected version travels with the link.</p>
          <button onClick={() => setOpen(true)} className="mt-7 inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-pink-500 to-violet-600 px-7 py-4 font-semibold shadow-lg transition hover:scale-105"><Pencil size={18} /> Change &amp; Share</button>
          {copied && <p className="mt-4 text-sm text-emerald-300">Share link copied!</p>}
        </div>
      </section>
      {open && <div className="fixed inset-0 z-[10000] grid place-items-center overflow-y-auto bg-black/90 p-4 backdrop-blur-md"><Editor data={data} setData={setData} onSave={saveAndShare} saving={saving} onClose={() => setOpen(false)} /></div>}
      {paymentOpen && <PaymentModal utr={paymentUtr} setUtr={setPaymentUtr} saving={saving} onPay={continueAfterPayment} onSecurePay={startSecurePayment} secureEnabled={Boolean(process.env.NEXT_PUBLIC_RAZORPAY_KEY_ID)} onClose={() => { if (!saving) { setPaymentOpen(false); setPendingSave(false); } }} />}
    </>
  );
}

function Editor({ data, setData, onSave, saving, onClose }: { data: CardData; setData: React.Dispatch<React.SetStateAction<CardData>>; onSave: () => void; saving: boolean; onClose: () => void }) {
  async function chooseImage(index: number, file?: File) {
    if (!file) return;
    try {
      const image = await compressImage(file);
      setData((d) => { const images = [...d.images]; images[index] = image; return { ...d, images }; });
    } catch { alert("Image upload failed."); }
  }
  return (
    <div className="relative w-full max-w-4xl rounded-3xl border border-white/15 bg-[#090914] p-6 text-white shadow-2xl md:p-8">
      <button onClick={onClose} className="absolute right-4 top-4 rounded-full p-2 text-white/60 hover:bg-white/10 hover:text-white"><X /></button>
      <h1 className="text-center text-2xl font-bold md:text-4xl">Change Your Birthday Card</h1>
      <p className="mt-2 text-center text-sm text-white/60">Girl keeps the original design. Boy uses a separate built-in boy set. Personal photos can still replace any slot.</p>

      <div className="mt-7 grid gap-3 md:grid-cols-2">
        <button type="button" onClick={() => setData((d) => ({ ...d, gender: "girl" }))} className={`rounded-2xl border p-4 text-left transition ${data.gender === "girl" ? "border-pink-400 bg-pink-500/15" : "border-white/10 bg-white/5"}`}><span className="block text-lg font-bold">Girl</span><span className="text-xs text-white/60">Original girl version</span></button>
        <button type="button" onClick={() => setData((d) => ({ ...d, gender: "boy" }))} className={`rounded-2xl border p-4 text-left transition ${data.gender === "boy" ? "border-blue-400 bg-blue-500/15" : "border-white/10 bg-white/5"}`}><span className="block text-lg font-bold">Boy</span><span className="text-xs text-white/60">New boy version</span></button>
      </div>

      <div className="mt-7 flex items-center gap-2 text-sm font-semibold text-fuchsia-200"><Users size={18} /> Selected: {data.gender === "girl" ? "Girl" : "Boy"}</div>
      <div className="mt-3 grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4">
        {data.images.map((image, index) => (
          <label key={index} className="cursor-pointer rounded-2xl border border-dashed border-fuchsia-400/40 bg-fuchsia-500/5 p-3 text-center hover:bg-fuchsia-500/10">
            {image ? <img src={image} alt={`Personal photo ${index + 1}`} className="mx-auto h-28 w-full rounded-xl object-cover" /> : <div className="grid h-28 place-items-center rounded-xl bg-white/5"><ImagePlus className="text-fuchsia-300" /></div>}
            <span className="mt-2 block text-xs font-semibold">Photo {index + 1} (optional)</span>
            <input type="file" accept="image/*" className="hidden" onChange={(e) => chooseImage(index, e.target.files?.[0])} />
          </label>
        ))}
      </div>

      <div className="mt-5 grid gap-4 md:grid-cols-2">
        <Field icon={<UserRound size={18} />} label="Name"><input value={data.name} onChange={(e) => setData((d) => ({ ...d, name: e.target.value }))} placeholder="Enter name" /></Field>
        <Field icon={<CalendarDays size={18} />} label="Birthday Date"><input type="date" value={data.date} onChange={(e) => setData((d) => ({ ...d, date: e.target.value }))} /></Field>
      </div>
      <Field icon={<MessageSquare size={18} />} label="Message (optional)"><textarea value={data.message} onChange={(e) => setData((d) => ({ ...d, message: e.target.value }))} placeholder="Write a special message..." rows={3} /></Field>
      <button onClick={onSave} disabled={saving} className="mt-6 w-full rounded-2xl bg-gradient-to-r from-pink-500 to-violet-600 py-4 font-bold transition hover:scale-[1.01] disabled:opacity-60">{saving ? "Opening payment..." : "Continue to ₹49 Payment"}</button>
    </div>
  );
}

function Field({ icon, label, children }: { icon: React.ReactNode; label: string; children: React.ReactNode }) {
  return <label className="mt-4 block"><span className="mb-2 flex items-center gap-2 text-sm font-semibold text-white/80">{icon}{label}</span><div className="[&_input]:w-full [&_input]:rounded-xl [&_input]:border [&_input]:border-white/10 [&_input]:bg-white/5 [&_input]:px-4 [&_input]:py-3 [&_input]:text-white [&_input]:outline-none [&_input]:focus:border-fuchsia-400 [&_textarea]:w-full [&_textarea]:rounded-xl [&_textarea]:border [&_textarea]:border-white/10 [&_textarea]:bg-white/5 [&_textarea]:px-4 [&_textarea]:py-3 [&_textarea]:text-white [&_textarea]:outline-none [&_textarea]:focus:border-fuchsia-400">{children}</div></label>;
}


function PaymentModal({ utr, setUtr, saving, onPay, onSecurePay, secureEnabled, onClose }: { utr: string; setUtr: (v: string) => void; saving: boolean; onPay: () => void; onSecurePay: () => void; secureEnabled: boolean; onClose: () => void }) {
  const upi = "8521536869@ibl";
  async function copyUpi() {
    try { await navigator.clipboard.writeText(upi); alert("UPI ID copied. Open your UPI app and pay ₹49 to this ID."); }
    catch { alert(`UPI ID: ${upi}`); }
  }
  return <div className="fixed inset-0 z-[11000] grid place-items-center overflow-y-auto bg-black/95 p-4 backdrop-blur-md">
    <div className="relative w-full max-w-md rounded-3xl border border-white/15 bg-[#090914] p-6 text-white shadow-2xl md:p-8">
      <button onClick={onClose} disabled={saving} className="absolute right-4 top-4 rounded-full p-2 text-white/60 hover:bg-white/10 hover:text-white disabled:opacity-40"><X /></button>
      <div className="mx-auto mb-4 grid h-14 w-14 place-items-center rounded-full bg-emerald-500/15 text-emerald-300"><ShieldCheck /></div>
      <h2 className="text-center text-2xl font-bold">Pay ₹49 to Create Link</h2>
      {secureEnabled ? <>
        <p className="mt-2 text-center text-sm text-white/60">Secure online payment is enabled. Payment is verified by the backend before your link is created.</p>
        <button type="button" onClick={onSecurePay} disabled={saving} className="mt-5 w-full rounded-2xl bg-emerald-500 py-4 font-bold text-black hover:bg-emerald-400 disabled:opacity-60">{saving ? "Opening secure payment..." : "Pay Securely ₹49"}</button>
        <div className="my-5 flex items-center gap-3 text-xs text-white/40"><span className="h-px flex-1 bg-white/10" />OR<span className="h-px flex-1 bg-white/10" /></div>
      </> : <p className="mt-2 text-center text-sm text-amber-200/70">Secure gateway is not configured yet. Manual QR payment is available below.</p>}
      <div className="rounded-2xl bg-white p-3"><img src="/payment/upi-qr.png" alt="Fixed UPI QR code" className="mx-auto aspect-square w-full max-w-[280px] object-contain" /></div>
      <div className="mt-4 rounded-2xl border border-white/10 bg-white/5 p-4">
        <div className="text-xs text-white/50">Fixed UPI ID</div><div className="mt-1 flex items-center justify-between gap-3"><span className="font-semibold">{upi}</span><button onClick={copyUpi} className="rounded-xl bg-white/10 p-2 hover:bg-white/15"><Copy size={17} /></button></div>
        <div className="mt-3 text-xs text-white/50">Amount</div><div className="mt-1 text-lg font-bold">₹49</div>
      </div>
      <button type="button" onClick={copyUpi} className="mt-4 flex w-full items-center justify-center gap-2 rounded-2xl bg-white/10 py-3 font-bold hover:bg-white/15"><Copy size={18} /> Copy UPI ID &amp; Pay ₹49</button>
      <label className="mt-5 block text-sm font-semibold text-white/80">UTR / Transaction ID<input value={utr} onChange={(e) => setUtr(e.target.value)} placeholder="Enter UTR after manual payment" className="mt-2 w-full rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-white outline-none focus:border-emerald-400" /></label>
      <button onClick={onPay} disabled={saving} className="mt-4 w-full rounded-2xl bg-gradient-to-r from-pink-500 to-violet-600 py-4 font-bold disabled:opacity-60">{saving ? "Creating link..." : "Manual Payment Done — Create Link"}</button>
      <p className="mt-3 text-center text-[11px] leading-5 text-white/40">Manual UTR entry is not automatic bank verification. For secure verification, use the secure payment button above.</p>
    </div>
  </div>;
}
