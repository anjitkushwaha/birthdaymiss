import { NextResponse } from "next/server";

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const url = typeof body?.url === "string" ? body.url : "";

    if (!url || !/^https?:\/\//i.test(url)) {
      return NextResponse.json({ error: "Invalid URL" }, { status: 400 });
    }

    // is.gd provides a small, permanent redirect URL without requiring an
    // API token. The full birthday data stays in the destination URL, so
    // shortening the link does not remove any personalization or images.
    const form = new URLSearchParams({ format: "simple", url });
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 2500);
    let response: Response;
    try {
      response = await fetch("https://is.gd/create.php", {
        method: "POST",
        headers: { "content-type": "application/x-www-form-urlencoded" },
        body: form.toString(),
        cache: "no-store",
        signal: controller.signal,
      });
    } finally {
      clearTimeout(timeout);
    }

    const result = (await response.text()).trim();
    if (!response.ok || !result.startsWith("https://is.gd/")) {
      return NextResponse.json({ error: result || "Shortener unavailable" }, { status: 502 });
    }

    return NextResponse.json({ shortUrl: result });
  } catch {
    return NextResponse.json({ error: "Could not shorten link" }, { status: 502 });
  }
}
