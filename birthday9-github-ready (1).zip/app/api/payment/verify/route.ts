import { NextResponse } from "next/server";
import crypto from "node:crypto";

export async function POST(request: Request) {
  try {
    const secret = process.env.RAZORPAY_KEY_SECRET;
    if (!secret) return NextResponse.json({ error: "Payment verification is not configured." }, { status: 503 });
    const body = await request.json();
    const orderId = String(body?.razorpay_order_id || "");
    const paymentId = String(body?.razorpay_payment_id || "");
    const signature = String(body?.razorpay_signature || "");
    if (!orderId || !paymentId || !signature) return NextResponse.json({ error: "Incomplete payment response." }, { status: 400 });
    const expected = crypto.createHmac("sha256", secret).update(`${orderId}|${paymentId}`).digest("hex");
    const a = Buffer.from(expected), b = Buffer.from(signature);
    const valid = a.length === b.length && crypto.timingSafeEqual(a, b);
    if (!valid) return NextResponse.json({ verified: false, error: "Payment signature verification failed." }, { status: 400 });

    const keyId = process.env.RAZORPAY_KEY_ID;
    if (!keyId) return NextResponse.json({ error: "Payment verification is not configured." }, { status: 503 });
    const auth = Buffer.from(`${keyId}:${secret}`).toString("base64");
    const paymentResponse = await fetch(`https://api.razorpay.com/v1/payments/${encodeURIComponent(paymentId)}`, { headers: { Authorization: `Basic ${auth}` }, cache: "no-store" });
    const payment = await paymentResponse.json();
    if (!paymentResponse.ok || payment?.order_id !== orderId || Number(payment?.amount) !== 4900 || payment?.currency !== "INR" || payment?.status !== "captured") {
      return NextResponse.json({ verified: false, error: "Payment was not captured for the required ₹49 order." }, { status: 400 });
    }
    return NextResponse.json({ verified: true, paymentId });
  } catch { return NextResponse.json({ error: "Payment verification failed." }, { status: 400 }); }
}
